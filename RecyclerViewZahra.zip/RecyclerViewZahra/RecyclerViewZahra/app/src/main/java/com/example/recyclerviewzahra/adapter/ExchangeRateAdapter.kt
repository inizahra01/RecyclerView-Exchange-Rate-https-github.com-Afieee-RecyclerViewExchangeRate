package com.example.recyclerviewzahra.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewzahra.ExchangeRate
import com.example.recyclerviewzahra.R

class ExchangeRateAdapter(private val exchangeRateList: List<ExchangeRate>) :
    RecyclerView.Adapter<ExchangeRateAdapter.ExchangeRateViewHolder>() {

    class ExchangeRateViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flagImage: ImageView = itemView.findViewById(R.id.flag_image)
        val countryName: TextView = itemView.findViewById(R.id.country_name)
        val buyRate: TextView = itemView.findViewById(R.id.buy_rate)
        val sellRate: TextView = itemView.findViewById(R.id.sell_rate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExchangeRateViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_exchange_rate, parent, false)
        return ExchangeRateViewHolder(view)
    }    override fun onBindViewHolder(holder: ExchangeRateViewHolder, position: Int) {
        val currentItem = exchangeRateList[position]

        // Set flag image directly using resource ID
        holder.flagImage.setImageResource(currentItem.flagResource)

        holder.countryName.text = currentItem.country
        holder.buyRate.text = currentItem.buyRate
        holder.sellRate.text = currentItem.sellRate
    }

    override fun getItemCount(): Int {
        return exchangeRateList.size
    }
}
