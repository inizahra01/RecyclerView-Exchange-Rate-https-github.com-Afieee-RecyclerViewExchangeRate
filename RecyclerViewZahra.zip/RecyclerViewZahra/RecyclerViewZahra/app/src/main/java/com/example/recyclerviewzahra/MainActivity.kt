package com.example.recyclerviewzahra

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewzahra.adapter.ExchangeRateAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var exchangeRateAdapter: ExchangeRateAdapter
    private lateinit var exchangeRateList: ArrayList<ExchangeRate>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        exchangeRateList = ArrayList()

        // Add data based on the design shown in the image
        addDataToList()

        exchangeRateAdapter = ExchangeRateAdapter(exchangeRateList)
        recyclerView.adapter = exchangeRateAdapter
    }
    private fun addDataToList() {
        // Adding data from the provided design with direct resource IDs
        exchangeRateList.add(ExchangeRate("Vietnam", R.drawable.vietnam, "1.403", "1.746"))
        exchangeRateList.add(ExchangeRate("Nicaragua", R.drawable.nicaragua, "9.123", "12.09"))
        exchangeRateList.add(ExchangeRate("Korea", R.drawable.korea, "3.704", "5.151"))
        exchangeRateList.add(ExchangeRate("Russia", R.drawable.russia, "116.0", "144.4"))
        exchangeRateList.add(ExchangeRate("China", R.drawable.china, "1.725", "2.234"))
        exchangeRateList.add(ExchangeRate("Portuguese", R.drawable.portuguese, "1.403", "1.746"))
        exchangeRateList.add(ExchangeRate("Korea", R.drawable.korea, "3.454", "4.312"))
        exchangeRateList.add(ExchangeRate("French", R.drawable.french, "23.45", "34.56"))
        exchangeRateList.add(ExchangeRate("Nicaragua", R.drawable.nicaragua, "263.1", "300.3"))
        exchangeRateList.add(ExchangeRate("China", R.drawable.china, "1.725", "2.234"))
    }
}
