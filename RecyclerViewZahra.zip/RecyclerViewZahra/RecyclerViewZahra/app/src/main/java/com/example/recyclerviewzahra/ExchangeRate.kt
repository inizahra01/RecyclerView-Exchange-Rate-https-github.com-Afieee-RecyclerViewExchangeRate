package com.example.recyclerviewzahra

data class ExchangeRate(
    var country: String,
    var flagResource: Int,
    var buyRate: String,
    var sellRate: String
)

